/*
 * Atmega328pb code.cpp
 *
 * Created: 5/27/2024 10:30:29 PM
 * Author : Dwight
 */ 
#define F_CPU 8000000UL
#include <avr/io.h>
#include <util/delay.h>
#include <avr/uart.h>
#include <avr/uart.c>
#include <stdlib.h>

char str[10];
float DC = 0;
uint8_t mode = 1;

/*void usart_init()
{
	UBRR1L = 51;
	UCSR1B = (1<<RXEN1) | (1<<TXEN1);
	UCSR1C = (1<<UCSZ11) | (1<<UCSZ10);
}

uint8_t uart_rec_int8()
{
	PORTB |= (1 << PB1);
	uint8_t num;
	while (!(UCSR1A & (1<<RXC1)));
	num = UDR1;
	PORTB &= ~(1 << PB1);
	return num;
	
}

void uart_send_int8(uint8_t num)
{
	PORTB |= (1 << PB0);
	while (!(UCSR1A & (1 << UDRE1)));
	UDR1 = num;
	_delay_ms(200);
	PORTB &= ~(1 << PB0);
}

void uart_send_int16(uint16_t num)
{
	int i;
	for (i = 1; i > -1; i--)
	{
		uint8_t shift = (num >> (8*i));
		uart_send_int8(shift);
	}
}

uint16_t uart_rec_int16()
{
	uint16_t num = 0;
	uint16_t shift;
	uint8_t read;
	int i;
	for (i = 1; i > -1; i--)
	{
		read = uart_rec_int8();
		shift = read;
		shift = (shift << (8*i));
		num = (num + shift);
	}
	return num;
}*/

int main(void)
{
			TIMSK1 |= (1 << OCIE1A);
			ADCSRA = 0b10000101;
			ADMUX |= (1<<REFS0);

			EIMSK = 0x03;
			TCCR1A = 0;
			TCCR1B |= (1 << WGM12)|(1 << CS11);
			OCR1A = 65535;
			DDRB = 0x07;
			
			usart_init(51);
			//send_string("Hello");

			
    while (1) 
    {
		//uart_send_int16(70);
		//uart_send_int16(0);
		if (mode == 0) 
		//Battery Voltage: Captures the Present DC voltage 
		//on the ADC1 which is connected to the Battery and Boost Converter.
		{
			ADMUX &= ~(7 << MUX0);
			ADMUX |= (1 << MUX0);
			ADCSRA |= (1 << ADSC);
			while ((ADCSRA &(1<<ADIF)) == 0);
			DC = ((ADC * 3.2)/1023);
			ADCSRA |= (1 <<ADIF);
			
			dtostrf(DC, 2, 1, str);
			send_string(str);
		}
		
		if (mode == 1)
		//Generator Voltage: Captures the Present DC voltage
		//on the ADC2 which is connected to the Generator(s).
		{
			ADMUX &= ~(7 << MUX0);
			ADMUX |= (2 << MUX0);
			ADCSRA |= (1 << ADSC);
			while ((ADCSRA &(1 << ADIF)) == 0);
			DC = ((ADC * 3.2)/1023);
			ADCSRA |= (1 << ADIF);
			
			dtostrf(DC, 2, 1, str);
			send_string(str);
			_delay_ms(250);
			//send_cr_lf();
			
		}
		
		if (mode == 2)
		//Load Current: Captures the Present net DC Current 
		//flowing from/to the battery.
		{
			ADMUX &= ~(7 << MUX0);
			ADCSRA |= (1 << ADSC);
			while ((ADCSRA &(1 << ADIF)) == 0);
			DC = ((ADC * 5));
			ADCSRA |= (1 << ADIF);
			
		}
    }
}

